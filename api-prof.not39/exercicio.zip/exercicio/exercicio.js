// Recebe o nome inserido no input como argumento
// Deve retornar um objeto com nome, avatar e url do perfil
export async function pegarDadosUsuario(nome) {

  return {
    nome: undefined,
    avatar: undefined,
    perfil: undefined
  }
}

// Recebe o nome inserido no input como argumento
// Deve retornar um array com os repositórios retornados da api
export async function pegarDadosRepositorios(nome) {

  return undefined
}

// Recebe o nome inserido no input como argumento
// Deve retornar um texto com o README retornado da api
export async function pegarDadosReadme(nome) {

    return undefined
}

